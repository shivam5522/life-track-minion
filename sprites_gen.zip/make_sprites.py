#!/usr/bin/env python3
"""
Pixel-art sprite sheet generator for a two-person health tracker.

Every frame is drawn procedurally, so you can recolor or restyle a character
by editing the CHARACTERS dict below and re-running:  python3 make_sprites.py

Outputs (per character): <name>_sheet.png (1x), <name>_sheet@4x.png,
<name>_preview.gif, plus sprites.json describing rows / frame counts / fps.
"""
import json, os, random, sys
from PIL import Image, ImageDraw, ImageFont

F = 48            # frame size in pixels
CX = 24           # horizontal centre (character is symmetric about 23.5)
OUTLINE = (34, 26, 32)
FLASH = (255, 210, 60)
EYE = (30, 22, 26)
TEETH = (250, 248, 244)
MOUTH_IN = (120, 40, 52)

CHARACTERS = {
    "him": dict(
        skin=(196, 142, 104), skin_shade=(166, 114, 80),
        hair=(30, 24, 26), hair_hi=(74, 62, 62), hair_style="short",
        brow=(30, 24, 26), beard=(40, 31, 31),
        shirt=(112, 36, 46), shirt_shade=(84, 26, 36), long_sleeves=False,
        print_col=(236, 230, 224), vneck=False,
        pants=(50, 62, 96), shoes=(236, 236, 240), shoe_shade=(186, 186, 196),
        watch=True, lip=(214, 128, 116), blush=None, blanket=(86, 120, 170)),
    "her": dict(
        skin=(192, 136, 100), skin_shade=(162, 110, 78),
        hair=(64, 39, 29), hair_hi=(140, 90, 56), hair_style="long",
        brow=(56, 36, 28), beard=None,
        shirt=(72, 66, 82), shirt_shade=(54, 50, 64), long_sleeves=True,
        print_col=None, vneck=True,
        pants=(62, 66, 92), shoes=(240, 240, 244), shoe_shade=(192, 192, 202),
        watch=False, lip=(176, 84, 84), blush=(216, 122, 112), blanket=(196, 120, 150)),
}

# ---------------------------------------------------------------- helpers
def rgba(c):
    return c if len(c) == 4 else (c[0], c[1], c[2], 255)

def R(d, x0, y0, x1, y1, c):
    if x1 >= x0 and y1 >= y0:
        d.rectangle([x0, y0, x1, y1], fill=rgba(c))

def P(d, x, y, c):
    d.point((x, y), fill=rgba(c))

def CLR(d, x0, y0, x1, y1):
    if x1 >= x0 and y1 >= y0:
        d.rectangle([x0, y0, x1, y1], fill=(0, 0, 0, 0))

def mx(x):
    return 2 * CX - 1 - x

def blank():
    return Image.new("RGBA", (F, F), (0, 0, 0, 0))

def outline_img(img, col):
    px = img.load(); w, h = img.size
    out = img.copy(); po = out.load(); c = rgba(col)
    for y in range(h):
        for x in range(w):
            if px[x, y][3] == 0:
                for ddx, ddy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    xx, yy = x + ddx, y + ddy
                    if 0 <= xx < w and 0 <= yy < h and px[xx, yy][3] > 0:
                        po[x, y] = c
                        break
    return out

def comp(fr, layer):
    return Image.alpha_composite(fr, layer)

def sticker(fr, fn, outline=True):
    lay = blank(); fn(ImageDraw.Draw(lay))
    if outline:
        lay = outline_img(lay, OUTLINE)
    return comp(fr, lay)

# ------------------------------------------------------------- character
FACES = {   # eyes, brows, mouth
    "neutral": ("open", "flat", "line"),
    "blink": ("closed", "flat", "line"),
    "happy": ("arc", "flat", "smile"),
    "grin": ("open", "proud", "grin"),
    "open": ("arc", "flat", "cheer"),
    "sad": ("open", "sad", "frown"),
    "tired": ("closed", "sad", "line"),
    "yawn": ("closed", "flat", "yawn"),
    "sleep": ("closed", "flat", "o"),
    "determined": ("open", "proud", "line"),
    "look_down": ("down", "flat", "line"),
}

def draw_character(ch, tier, pose):
    p = dict(dy=0, bob=0, slump=0, arms="down", legs="stand", face="neutral", outline=OUTLINE)
    p.update(pose)
    img = blank(); d = ImageDraw.Draw(img)
    dy = p["dy"]; u = dy + p["bob"]; s = p["slump"]
    tw = [8, 10, 12, 14][tier]; aw = [2, 2, 3, 4][tier]
    TL = CX - tw // 2; TR = TL + tw - 1
    hy = 16 + u + s
    sk, sk2 = ch["skin"], ch["skin_shade"]
    sh, sh2 = ch["shirt"], ch["shirt_shade"]
    long_sl = ch["long_sleeves"]

    # back hair (long style falls to the shoulders, lighter at the ends)
    if ch["hair_style"] == "long":
        ends = {CX - 7: hy + 11, CX - 6: hy + 13, CX - 5: hy + 12}
        for x, yend in ends.items():
            for y in range(hy + 2, yend + 1):
                c = ch["hair_hi"] if y >= hy + 10 else ch["hair"]
                P(d, x, y, c); P(d, mx(x), y, c)

    # legs
    lw = 4 if tier == 3 else 3
    lifts = {"stand": (0, 0), "walkA": (2, 0), "walkB": (0, 2), "tuck": (2, 2)}[p["legs"]]
    for i, x0 in enumerate((CX - 1 - lw, CX + 1)):
        bot = 44 + dy - lifts[i]; top = 38 + dy
        R(d, x0, top, x0 + lw - 1, bot - 2, ch["pants"])
        sx0 = x0 - 1 if i == 0 else x0
        R(d, sx0, bot - 1, sx0 + lw, bot, ch["shoes"])
        R(d, sx0, bot, sx0 + lw, bot, ch["shoe_shade"])

    # torso
    ty0, ty1 = 28 + u, 37 + u
    R(d, TL, ty0, TR, ty1 - 1, sh)
    R(d, TR, ty0 + 1, TR, ty1 - 1, sh2)
    taper = max(0, tier - 1)
    if taper:
        CLR(d, TL, ty1 - 2, TL + taper - 1, ty1 - 1)
        CLR(d, TR - taper + 1, ty1 - 2, TR, ty1 - 1)
        R(d, TR - taper, ty1 - 2, TR - taper, ty1 - 1, sh2)
    R(d, TL + taper, ty1, TR - taper, ty1, ch["pants"])
    if tier >= 2:
        R(d, CX - 4, ty0 + 4, CX - 2, ty0 + 4, sh2); R(d, CX + 1, ty0 + 4, CX + 3, ty0 + 4, sh2)
    if tier == 3:
        P(d, CX - 5, ty0 + 3, sh2); P(d, CX + 4, ty0 + 3, sh2)
        R(d, CX - 1, ty0 + 6, CX, ty0 + 7, sh2)
    if ch["vneck"]:
        R(d, CX - 2, ty0, CX + 1, ty0, sk); R(d, CX - 1, ty0 + 1, CX, ty0 + 2, sk)
    if ch["print_col"]:
        R(d, CX + 1, ty0 + 6, CX + 3, ty0 + 6, ch["print_col"]); P(d, CX + 2, ty0 + 7, ch["print_col"])

    # neck
    nx0, nx1 = (CX - 3, CX + 2) if tier == 3 else (CX - 2, CX + 1)
    R(d, nx0, 26 + u, nx1, 27 + u, sk2)

    # arms ---------------------------------------------------------------
    sy = 29 + u

    def arm_rects(mode, off):
        """Rects for the viewer-left arm: (x0, y0, x1, y1, kind)."""
        y = sy + off; a0, a1 = TL - aw, TL - 1; r = []
        if mode in ("down", "droop"):
            if mode == "droop":
                y += 1
            r += [(a0, y + 3, a1, y + 6, "upper"), (a0, y + 7, a1, y + 8, "hand")]
            if tier == 3:
                r.append((a0 - 1, y + 3, a0 - 1, y + 4, "upper"))
            r += [(a0, y, a1, y + 2, "sleeve"), (a0, y + 6, a1, y + 6, "wrist")]
        elif mode == "flex":
            L = 4 + tier
            bw, bh = 1 + tier, 1 + tier // 2
            r += [(TL - L, y, TL - 1, y + aw - 1, "upper"),
                  (TL - L, y - 6, TL - L + aw - 1, y - 1, "upper"),
                  (TL - L, y - 8, TL - L + aw - 1, y - 7, "hand"),
                  (TL - L + aw, y - bh, min(TL - 1, TL - L + aw + bw - 1), y - 1, "upper"),
                  (TL - 3, y, TL - 1, y + aw - 1, "sleeve"),
                  (TL - L, y - 6, TL - L + aw - 1, y - 6, "wrist")]
        elif mode == "up":
            r += [(a0, y - 3, a1, y + 1, "upper"),
                  (a0 - 1, y - 8, a1 - 1, y - 4, "upper"),
                  (a0 - 1, y - 10, a1 - 1, y - 9, "hand"),
                  (a0, y - 1, a1, y + 1, "sleeve"),
                  (a0 - 1, y - 8, a1 - 1, y - 8, "wrist")]
        return r

    def mirror(rects):
        return [(mx(x1), y0, mx(x0), y1, k) for (x0, y0, x1, y1, k) in rects]

    def paint(rects, is_right):
        for (x0, y0, x1, y1, k) in rects:
            if k == "wrist":
                if ch["watch"] and is_right:
                    R(d, x0, y0, x1, y1, (24, 24, 28)); P(d, (x0 + x1) // 2, y0, (90, 200, 210))
                continue
            col = {"skin": sk, "hand": sk, "sleeve": sh, "upper": sh if long_sl else sk}[k]
            R(d, x0, y0, x1, y1, col)

    am = p["arms"]
    lo = ro = 0
    if am == "swingA":
        lm, rm, lo, ro = "down", "down", 1, -1
    elif am == "swingB":
        lm, rm, lo, ro = "down", "down", -1, 1
    elif am in ("drink", "cup"):
        lm, rm = "down", am
    else:
        lm = rm = am

    paint(arm_rects(lm, lo), False)
    cup_rects = []
    if rm == "drink":
        paint([(TR + 1, hy + 8, TR + aw, sy + 5, "upper"), (TR + 1, sy, TR + aw, sy + 2, "sleeve"),
               (CX + 3, hy + 6, TR + aw, hy + 8, "hand"), (TR + 1, hy + 9, TR + aw, hy + 9, "wrist")], True)
        cup_rects = [(CX + 1, hy + 5, CX + 3, hy + 9)]
    elif rm == "cup":
        paint([(TR + 1, sy + 3, TR + aw, sy + 5, "upper"), (TR + 1, sy, TR + aw, sy + 2, "sleeve"),
               (TR - 1, sy + 5, TR + aw, sy + 6, "hand"), (TR + 1, sy + 4, TR + aw, sy + 4, "wrist")], True)
        cup_rects = [(TR - 3, sy + 1, TR - 1, sy + 6)]
    else:
        paint(mirror(arm_rects(rm, ro)), True)

    # head -----------------------------------------------------------------
    R(d, CX - 4, hy, CX + 3, hy, sk); R(d, CX - 5, hy + 1, CX + 4, hy + 8, sk); R(d, CX - 4, hy + 9, CX + 3, hy + 9, sk)
    h, hi = ch["hair"], ch["hair_hi"]
    if ch["hair_style"] == "short":
        P(d, CX - 6, hy + 4, sk); P(d, CX - 6, hy + 5, sk2); P(d, CX + 5, hy + 4, sk); P(d, CX + 5, hy + 5, sk2)
        R(d, CX - 2, hy - 3, CX + 1, hy - 3, h)
        R(d, CX - 4, hy - 2, CX + 3, hy - 2, h)
        R(d, CX - 5, hy - 1, CX + 4, hy + 1, h)
        R(d, CX - 5, hy + 2, CX - 4, hy + 2, h); R(d, CX + 3, hy + 2, CX + 4, hy + 2, h)
        R(d, CX - 5, hy + 3, CX - 5, hy + 3, h); R(d, CX + 4, hy + 3, CX + 4, hy + 3, h)
        P(d, CX - 2, hy - 2, hi); P(d, CX - 1, hy - 3, hi); P(d, CX + 1, hy - 1, hi)
    else:
        R(d, CX - 4, hy - 1, CX + 3, hy - 1, h)
        R(d, CX - 5, hy, CX + 4, hy + 2, h)
        P(d, CX - 1, hy, sk2); P(d, CX - 1, hy + 1, sk2)            # centre part
        R(d, CX - 5, hy + 3, CX - 5, hy + 9, h); R(d, CX + 4, hy + 3, CX + 4, hy + 9, h)
        P(d, CX - 4, hy + 3, h); P(d, CX + 3, hy + 3, h)
        P(d, CX - 3, hy + 1, hi); P(d, CX + 2, hy + 1, hi); P(d, CX - 5, hy + 8, hi); P(d, CX + 4, hy + 8, hi)

    # beard
    if ch["beard"]:
        b = ch["beard"]
        R(d, CX - 5, hy + 4, CX - 5, hy + 8, b); R(d, CX + 4, hy + 4, CX + 4, hy + 8, b)
        R(d, CX - 4, hy + 7, CX + 3, hy + 9, b)
        R(d, CX - 3, hy + 10, CX + 2, hy + 10, b)

    # face
    eyes, brows, mouth = FACES[p["face"]]
    ey, my = hy + 5, hy + 8
    bc = ch["brow"]
    thick = ch["beard"] is not None
    if brows == "flat":
        R(d, CX - 4, ey - 2, CX - 2, ey - 2, bc); R(d, CX + 1, ey - 2, CX + 3, ey - 2, bc)
    elif brows == "sad":
        for (x, y) in ((CX - 4, ey - 1), (CX - 3, ey - 1), (CX - 2, ey - 2)):
            P(d, x, y, bc); P(d, mx(x), y, bc)
    elif brows == "proud":
        for (x, y) in ((CX - 4, ey - 2), (CX - 3, ey - 2), (CX - 2, ey - 1)):
            P(d, x, y, bc); P(d, mx(x), y, bc)
    if thick and brows == "flat":
        P(d, CX - 3, ey - 3, bc); P(d, CX + 2, ey - 3, bc)

    for x in (CX - 3, CX + 2):
        side = -1 if x < CX else 1
        if eyes == "open":
            R(d, x, ey, x, ey + 1, EYE)
        elif eyes == "down":
            P(d, x, ey + 1, EYE)
        elif eyes == "arc":
            P(d, x - 1, ey + 1, EYE); P(d, x, ey, EYE); P(d, x + 1, ey + 1, EYE)
        elif eyes == "closed":
            R(d, min(x, x + side), ey + 1, max(x, x + side), ey + 1, EYE)

    ml = ch["lip"] if ch["beard"] else EYE
    if mouth == "line":
        R(d, CX - 1, my, CX, my, ml)
    elif mouth == "smile":
        P(d, CX - 2, my - 1, ml); R(d, CX - 1, my, CX, my, ml); P(d, CX + 1, my - 1, ml)
    elif mouth == "grin":
        R(d, CX - 2, my, CX + 1, my, TEETH); P(d, CX - 3, my - 1, ml); P(d, CX + 2, my - 1, ml)
    elif mouth == "frown":
        P(d, CX - 2, my, ml); R(d, CX - 1, my - 1, CX, my - 1, ml); P(d, CX + 1, my, ml)
    elif mouth == "cheer":
        R(d, CX - 2, my - 1, CX + 1, my, MOUTH_IN); R(d, CX - 2, my - 1, CX + 1, my - 1, TEETH)
    elif mouth == "yawn":
        R(d, CX - 1, my - 1, CX, my, MOUTH_IN)
    elif mouth == "o":
        P(d, CX, my, ml)
    if ch["blush"] and p["face"] in ("happy", "open", "grin"):
        P(d, CX - 4, hy + 7, ch["blush"]); P(d, CX + 3, hy + 7, ch["blush"])

    # held cup (drawn last so it sits in front)
    for (x0, y0, x1, y1) in cup_rects:
        R(d, x0, y0, x1, y1, (196, 226, 250)); R(d, x0, y0 + 2, x1, y1, (90, 160, 235))

    return outline_img(img, p["outline"])

# --------------------------------------------------------------- effects
def shadow(fr, dy=0, tier=1, half=None):
    lay = blank(); d = ImageDraw.Draw(lay)
    hw = max(3, (half or 7 + tier) - (-dy) // 2)
    d.rectangle([CX - hw, 45, CX + hw - 1, 45], fill=(0, 0, 0, 55))
    d.rectangle([CX - hw + 2, 46, CX + hw - 3, 46], fill=(0, 0, 0, 38))
    return comp(fr, lay)

def sparkle(d, x, y, big=False, c=(255, 226, 110)):
    P(d, x, y, (255, 255, 240))
    for k in ((1, 2) if big else (1,)):
        for ddx, ddy in ((k, 0), (-k, 0), (0, k), (0, -k)):
            P(d, x + ddx, y + ddy, c)

def cloud(fr, x, y, i):
    def f(d):
        R(d, x + 3, y, x + 7, y, (170, 176, 192)); R(d, x + 1, y + 1, x + 9, y + 1, (170, 176, 192))
        R(d, x, y + 2, x + 10, y + 3, (150, 156, 174)); R(d, x + 1, y + 4, x + 9, y + 4, (130, 136, 156))
    fr = sticker(fr, f)
    d = ImageDraw.Draw(fr)
    for k in range(3):
        dx = x + 2 + 3 * k; dyy = y + 6 + ((i + k) % 3) * 2
        R(d, dx, dyy, dx, dyy + 1, (110, 165, 235))
    return fr

def sun(fr, i):
    fr = sticker(fr, lambda d: (R(d, 4, 2, 7, 9, (255, 204, 66)), R(d, 2, 4, 9, 7, (255, 204, 66)),
                               R(d, 3, 3, 8, 8, (255, 204, 66)), P(d, 4, 4, (255, 240, 170))))
    d = ImageDraw.Draw(fr)
    rays = [(5, 12), (12, 5), (11, 11)] if i % 2 == 0 else [(5, 13), (13, 6), (12, 12), (1, 12), (12, 1)]
    for (x, y) in rays:
        P(d, x, y, (255, 214, 90))
    return fr

def zz(d, x, y, c=(110, 130, 220)):
    R(d, x, y, x + 3, y, c); P(d, x + 2, y + 1, c); P(d, x + 1, y + 2, c); R(d, x, y + 3, x + 3, y + 3, c)

def puff(fr, cx, cy, r):
    d = ImageDraw.Draw(fr)
    for ddx, ddy in ((1, 0), (-1, 0), (0, -1), (1, -1), (-1, -1), (1, 1), (-1, 1)):
        P(d, cx + ddx * r, cy + ddy * r, (228, 228, 236))
        P(d, cx + ddx * r + (1 if ddx >= 0 else -1), cy + ddy * r, (200, 200, 212))
    return fr

def sweat(fr, x, y):
    d = ImageDraw.Draw(fr)
    P(d, x, y, (150, 200, 250)); R(d, x - 1, y + 1, x + 1, y + 2, (110, 170, 240)); P(d, x, y + 3, (110, 170, 240))
    return fr

def badge(fr, kind):
    def f(d):
        if kind == "check":
            R(d, 39, 3, 43, 9, (86, 186, 110)); R(d, 38, 4, 44, 8, (86, 186, 110))
            for (x, y) in ((39, 6), (40, 7), (41, 6), (42, 5), (43, 4)):
                P(d, x, y, (255, 255, 255))
        else:  # water drop
            P(d, 41, 2, (90, 160, 235)); R(d, 40, 3, 42, 4, (90, 160, 235))
            R(d, 39, 5, 43, 8, (90, 160, 235)); R(d, 40, 9, 42, 9, (90, 160, 235)); P(d, 40, 6, (200, 230, 255))
    return sticker(fr, f)

def confetti(fr, i, seed=7):
    rng = random.Random(seed); d = ImageDraw.Draw(fr)
    cols = [(255, 99, 132), (255, 205, 86), (75, 192, 192), (54, 162, 235), (153, 102, 255), (120, 220, 120)]
    for _ in range(20):
        x = rng.randrange(1, F - 2); y0 = rng.randrange(0, 40); sp = rng.choice((3, 4, 5)); c = rng.choice(cols)
        y = (y0 + i * sp) % 42
        R(d, x, y, x + (i + x) % 2, y + (1 - (i + x) % 2), c)
    return fr

def aura(fr, i):
    d = ImageDraw.Draw(fr)
    for k, x in enumerate((8, 12, 35, 39)):
        y = 40 - ((i * 4 + k * 7) % 26)
        R(d, x, y, x, y + 2, (255, 222, 100))
    return fr

def scale(fr, blink):
    def f(d):
        R(d, CX - 9, 43, CX + 8, 45, (196, 202, 214)); R(d, CX - 9, 43, CX + 8, 43, (232, 236, 244))
        R(d, CX - 3, 44, CX + 2, 45, (40, 44, 52))
    fr = sticker(fr, f)
    d = ImageDraw.Draw(fr)
    if blink is None:
        R(d, CX - 2, 44, CX + 1, 44, (110, 230, 140))
    elif blink:
        P(d, CX - 2, 44, (110, 230, 140)); P(d, CX, 44, (110, 230, 140))
    else:
        P(d, CX - 1, 44, (110, 230, 140)); P(d, CX + 1, 44, (110, 230, 140))
    return fr

# ------------------------------------------------------------ animations
TIER_FACE = ["tired", "neutral", "happy", "grin"]

def base_pose(t, **kw):
    pz = dict(slump=1 if t == 0 else 0, arms="droop" if t == 0 else "down", face=TIER_FACE[t])
    pz.update(kw)
    return pz

def frame(ch, t, pose, under=None, over=None, shadow_on=True):
    fr = blank()
    if shadow_on:
        fr = shadow(fr, pose.get("dy", 0), t)
    if under:
        fr = under(fr)
    fr = comp(fr, draw_character(ch, t, pose))
    if over:
        fr = over(fr)
    return fr

def anim_idle(ch, t):
    out = []
    for i, bob in enumerate((0, 0, 1, 1)):
        pz = base_pose(t, bob=bob)
        over = None
        if t == 0 and i >= 2:
            over = lambda fr: sweat(fr, 31, 18)
        if t in (1, 2) and i == 3:
            pz["face"] = "blink"
        if t == 3:
            pz["arms"] = "flex"
            if i in (0, 2):
                over = lambda fr, i=i: sticker(fr, lambda d: sparkle(d, 9 if i == 0 else 38, 19, big=True), outline=False)
        out.append(frame(ch, t, pz, over=over))
    return out

def anim_walk(ch, t):
    legs = ("walkA", "stand", "walkB", "stand"); arms = ("swingA", "down", "swingB", "down")
    return [frame(ch, t, base_pose(t, legs=legs[i], arms=arms[i], dy=(0, -1, 0, -1)[i])) for i in range(4)]

def anim_drink(ch, t):
    arms = ["cup", "cup", "drink", "drink", "drink", "drink", "cup", "cup"]
    faces = [TIER_FACE[t], TIER_FACE[t], "blink", "blink", "blink", "blink", "happy", "happy"]
    out = []
    for i in range(8):
        pz = base_pose(t, arms=arms[i], face=faces[i], bob=(0, 0, 0, 1, 0, 1, 0, 0)[i])
        if i >= 6:
            pz["slump"] = 0
        out.append(frame(ch, t, pz, over=(lambda fr: badge(fr, "water")) if i >= 6 else None))
    return out

def anim_weigh(ch, t):
    dys = [-4, -1, -2, -2, -2, -2, -2, -2]
    faces = [TIER_FACE[t], TIER_FACE[t], "look_down", "look_down", "look_down", "look_down", "happy", "happy"]
    out = []
    for i in range(8):
        blink = None if i >= 6 else (i % 2 == 0 if i >= 2 else False)
        pz = base_pose(t, dy=dys[i], face=faces[i])
        fr = shadow(blank(), 0, t, half=10)
        fr = scale(fr, blink)
        fr = comp(fr, draw_character(ch, t, pz))
        if i >= 6:
            fr = badge(fr, "check")
        out.append(fr)
    return out

def anim_sleep(ch, t):
    body = draw_character(ch, t, dict(face="sleep", arms="down")).transpose(Image.Transpose.ROTATE_90)
    bb = body.getbbox()
    ox, oy = 5 - bb[0], 42 - bb[3]
    aw = [2, 2, 3, 4][t]; tw = [8, 10, 12, 14][t]
    TL = CX - tw // 2; TR = TL + tw - 1
    top = 47 - (TR + aw + 1) + oy           # top edge of the lying body
    bx0, bx1 = 27 + ox, 45 + ox             # blanket covers torso to feet
    out = []
    for i in range(4):
        fr = blank()
        fr = sticker(fr, lambda d: (R(d, 2, 42, 45, 44, (150, 104, 72)), R(d, 2, 42, 45, 42, (182, 132, 92)),
                                    R(d, 2, 45, 3, 46, (120, 82, 56)), R(d, 44, 45, 45, 46, (120, 82, 56))))
        fr = sticker(fr, lambda d: R(d, 3, top + 4, 14, 41, (244, 244, 250)))
        fr = comp(fr, _shift(body, ox, oy))
        breath = 1 if i in (1, 2) else 0
        bl = ch["blanket"]
        light = tuple(min(255, c + 45) for c in bl); dark = tuple(max(0, c - 30) for c in bl)
        bt = top + 3 - breath
        def blanket(d):
            R(d, bx0, bt, bx1, 41, bl)
            R(d, bx0 + 1, bt, bx1 - 1, bt, light)
            CLR(d, bx1, bt, bx1, bt)                     # rounded foot corner
            R(d, bx0, bt, bx0 + 2, 41, (240, 240, 246))  # folded-down sheet
            R(d, bx0 + 3, bt + 1, bx0 + 3, 41, dark)
            R(d, bx0 + 9, bt + 3, bx1 - 2, bt + 3, dark)  # quilt stitch
        fr = sticker(fr, blanket)
        d = ImageDraw.Draw(fr)
        zz(d, 14 + i, top - 6 - i * 2)
        if i >= 2:
            zz(d, 20, top - 12 - (i - 2) * 2, (150, 165, 235))
        out.append(fr)
    return out

def _shift(img, ox, oy):
    lay = blank(); lay.paste(img, (ox, oy), img); return lay

def anim_wake_sad(ch):
    out = []
    specs = [(1, dict(arms="up", face="yawn")), (1, dict(arms="up", face="yawn", bob=1)),
             (1, dict(face="tired")), (0, None), (0, None), (0, None), (0, None), (0, None)]
    for i, (t, extra) in enumerate(specs):
        pz = base_pose(t, face="sad") if extra is None else dict(extra)
        if i in (5, 7):
            pz["bob"] = 1
        over = None
        if i == 3:
            over = lambda fr: puff(puff(fr, 14, 31, 2), 33, 31, 2)
        elif i >= 4:
            over = lambda fr, i=i: cloud(fr, 19, 1, i) if i < 7 else sweat(cloud(fr, 19, 1, i), 31, 18)
        out.append(frame(ch, t, pz, over=over))
    return out

def anim_wake_happy(ch):
    t = 1
    specs = [dict(arms="up", face="yawn"), dict(arms="up", face="yawn", bob=1), dict(face="happy"),
             dict(face="happy", bob=1), dict(arms="up", face="open", dy=-1), dict(arms="up", face="open", dy=-2),
             dict(face="happy"), dict(face="happy", bob=1)]
    out = []
    for i, pz in enumerate(specs):
        def over(fr, i=i):
            if i >= 2:
                fr = sun(fr, i)
            if i == 5:
                fr = sticker(fr, lambda d: (sparkle(d, 10, 16, True), sparkle(d, 38, 14, True)), outline=False)
            return fr
        out.append(frame(ch, t, pz, over=over))
    return out

def anim_power_up(ch):
    specs = [(1, "determined", "down", False), (1, "determined", "down", True), (2, "happy", "down", False),
             (2, "happy", "down", True), (3, "grin", "flex", True), (3, "grin", "flex", False),
             (3, "grin", "flex", False), (3, "grin", "flex", False)]
    out = []
    for i, (t, face, arms, flash) in enumerate(specs):
        pz = dict(face=face, arms=arms, outline=FLASH if flash else OUTLINE, bob=1 if i == 7 else 0)
        def over(fr, i=i):
            if i < 6:
                fr = aura(fr, i)
            if i >= 4:
                pts = [(8, 18), (39, 20), (12, 9), (36, 8)]
                fr = sticker(fr, lambda d: [sparkle(d, x, y, big=(k + i) % 2 == 0) for k, (x, y) in enumerate(pts[: 2 + i % 3])], outline=False)
            return fr
        out.append(frame(ch, t, pz, over=over))
    return out

def anim_power_down(ch):
    specs = [(2, "neutral", None), (2, "sad", None), (1, "sad", "puff"), (1, "sad", None),
             (0, "sad", "puff"), (0, "sad", None), (0, "sad", "sweat"), (0, "tired", "sweat")]
    out = []
    for i, (t, face, fx) in enumerate(specs):
        pz = base_pose(t, face=face)
        if t > 0:
            pz["arms"] = "down"
        def over(fr, fx=fx, t=t):
            if fx == "puff":
                fr = puff(puff(fr, 13 - t, 31, 2), 34 + t, 31, 2)
            if fx == "sweat":
                fr = sweat(fr, 31, 18)
            return fr
        out.append(frame(ch, t, pz, over=over))
    return out

def anim_celebrate(ch):
    t = 3
    dys = [0, -3, -6, -7, -6, -3, 0, 0]
    legs = ["stand", "tuck", "tuck", "tuck", "tuck", "tuck", "stand", "stand"]
    arms = ["down", "up", "up", "up", "up", "up", "flex", "flex"]
    faces = ["happy", "open", "open", "open", "open", "open", "grin", "grin"]
    out = []
    for i in range(8):
        pz = dict(dy=dys[i], legs=legs[i], arms=arms[i], face=faces[i], bob=1 if i == 0 else 0)
        out.append(frame(ch, t, pz, over=lambda fr, i=i: confetti(fr, i)))
    return out

# ------------------------------------------------------------ assemble
FPS = dict(idle=4, walk=8, drink=6, weigh=6, sleep=3, wake_sad=6, wake_happy=6,
           power_up=8, power_down=6, celebrate_month=10)

def build(ch):
    rows = []
    for t in range(4):
        rows.append((f"idle_t{t}", "idle", anim_idle(ch, t)))
    for t in range(4):
        rows.append((f"walk_t{t}", "walk", anim_walk(ch, t)))
    for t in range(4):
        rows.append((f"drink_t{t}", "drink", anim_drink(ch, t)))
    for t in range(4):
        rows.append((f"weigh_t{t}", "weigh", anim_weigh(ch, t)))
    for t in range(4):
        rows.append((f"sleep_t{t}", "sleep", anim_sleep(ch, t)))
    rows.append(("wake_sad", "wake_sad", anim_wake_sad(ch)))
    rows.append(("wake_happy", "wake_happy", anim_wake_happy(ch)))
    rows.append(("power_up", "power_up", anim_power_up(ch)))
    rows.append(("power_down", "power_down", anim_power_down(ch)))
    rows.append(("celebrate_month", "celebrate_month", anim_celebrate(ch)))
    return rows

ONE_SHOT = {"weigh", "wake_sad", "wake_happy", "power_up", "power_down", "celebrate_month"}

def write_outputs(out_dir):
    os.makedirs(out_dir, exist_ok=True)
    meta = {"frame_width": F, "frame_height": F, "columns": 8,
            "tiers": {"t0": "behind / missed goal", "t1": "baseline", "t2": "on track", "t3": "goal hit (buff)"},
            "animations": {}}
    for name, ch in CHARACTERS.items():
        rows = build(ch)
        sheet = Image.new("RGBA", (F * 8, F * len(rows)), (0, 0, 0, 0))
        for r, (aname, kind, frames) in enumerate(rows):
            for c, fr in enumerate(frames):
                sheet.paste(fr, (c * F, r * F))
            if name == list(CHARACTERS)[0]:
                meta["animations"][aname] = {"row": r, "frames": len(frames), "fps": FPS[kind],
                                             "loop": kind not in ONE_SHOT}
        sheet.save(os.path.join(out_dir, f"{name}_sheet.png"))
        sheet.resize((sheet.width * 4, sheet.height * 4), Image.NEAREST).save(os.path.join(out_dir, f"{name}_sheet@4x.png"))
        preview(rows, os.path.join(out_dir, f"{name}_preview.gif"), name)
    with open(os.path.join(out_dir, "sprites.json"), "w") as fh:
        json.dump(meta, fh, indent=2)

def preview(rows, path, title):
    S = 3; cell = F * S; lab = 16; cols = 5
    layout = [rows[0:4], rows[4:8], rows[8:12], rows[12:16], rows[16:20], rows[20:25]]
    W = cols * cell; H = len(layout) * (cell + lab)
    try:
        font = ImageFont.load_default(size=11)
    except TypeError:
        font = ImageFont.load_default()
    frames = []
    for i in range(8):
        img = Image.new("RGB", (W, H), (246, 243, 236)); d = ImageDraw.Draw(img)
        for r, group in enumerate(layout):
            for c, (aname, kind, fr_list) in enumerate(group):
                x, y = c * cell, r * (cell + lab)
                d.rectangle([x + 2, y + 2, x + cell - 3, y + cell - 3], fill=(236, 232, 222) if (r + c) % 2 else (240, 237, 228))
                fr = fr_list[i % len(fr_list)].resize((cell, cell), Image.NEAREST)
                img.paste(fr, (x, y), fr)
                d.text((x + 6, y + cell + 1), aname, fill=(80, 70, 70), font=font)
        frames.append(img)
    frames[0].save(path, save_all=True, append_images=frames[1:], duration=160, loop=0, disposal=2)

if __name__ == "__main__":
    write_outputs(sys.argv[1] if len(sys.argv) > 1 else "sprites_out")
